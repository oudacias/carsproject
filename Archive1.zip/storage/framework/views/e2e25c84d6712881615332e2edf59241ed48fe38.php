<link rel='stylesheet' href="/css/popup.css">
<link rel='stylesheet' href="/css/confirmation.css">
<?php echo $__env->make('Components.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
	<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
	<?php endif; ?>
	<div class="text_header">Liste des Utilisateurs</div>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Nom </th>
      <th scope="col">Prenom </th>
	  <th scope="col">Email </th>
	  <th scope="col">Telephone</th>
	  <th scope="col">Objectif</th>
      <th scope="col">Confirmer</th>
      <th scope="col">Supprimer</th>

    </tr>
  </thead>
  <tbody>
	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
	  <td><?php echo e($u->created_at->todatestring()); ?></td>
	  <td><?php echo e($u->nom); ?></td>
	  <td><?php echo e($u->prenom); ?></td>
	  <td><?php echo e($u->email); ?></td>
	  <td><?php echo e($u->telephone); ?></td>
	  <td><?php echo e($u->objectif); ?></td>
		<td><a href="/Admin/Admin_users/<?php echo e($u->id); ?>"><img src="/project_images/confirm.png" width="20%"></a></td>
		<td><a href="/Admin/confirmer_users/<?php echo e($u->id); ?>"><img src="/project_images/bin.png" width="20%"></a></td>

	  </tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    
    </div></div>
  </div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Admin/Admin_users.blade.php ENDPATH**/ ?>