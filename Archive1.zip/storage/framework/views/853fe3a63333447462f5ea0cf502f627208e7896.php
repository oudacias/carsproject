<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<div style="float:left; margin-left:100px">
<?php if(Session::get('categorie')): ?>
    <?php $__currentLoopData = Session::get('categorie'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="filter-element"><?php echo e($s); ?><a style="margin-left:5px" href="/Article/Articles/<?php echo e($s); ?>">x</a></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<hr/>
</div>
<form method="post" action="<?php echo e(action('ArticleController@TrouverCategorie')); ?>">
<?php echo csrf_field(); ?>
<div style="float:right;margin-right:100px">Categorie :
<select class="filter-select" name="categorie">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option value="<?php echo e($c->categorie); ?>"><?php echo e($c->categorie); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<input width="35px" style="position:absolute;margin-top:8px" type="image" src="/project_images/filter.png" alt="submit" />
</form>
</div>
<br>
<br>
<br>
<br>
<h4>Nos Articles</h4>
<div class="container">
    <?php $__currentLoopData = $artc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row card_gap">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-block">
                        <div class="user-image article-image">
                            <img src="<?php echo e($a->lien_image); ?>">
                        </div>
                    </div>
                </div>
            <div class="col-md-8">
                <div class="card-block">
                    <div class="card-introduction">
                        <strong><?php echo e($a->titre); ?></strong>
                        <p class="m-t-13 text-muted"><?php echo html_entity_decode(Str::limit($a->texte, 650)); ?></p><a href="/Articles/Article/<?php echo e($a->id); ?>">Lire Plus</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
</div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Articles/Articles.blade.php ENDPATH**/ ?>