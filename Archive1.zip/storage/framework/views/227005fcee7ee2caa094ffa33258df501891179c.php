<link rel='stylesheet' href="/css/popup.css">
<link rel='stylesheet' href="/css/confirmation.css">
<link rel='stylesheet' href="/css/articles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<?php echo $__env->make('Components.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
	<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
	<?php endif; ?>
	<div class="text_header">Nombre de click</div>
        <table class="table">
            <thead>
                <tr>
                <th scope="col">Lien Voiture</th>
                <th scope="col">Description</th>
                <th scope="col">Nombre de click</th>
                
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="text-align:left">
                <td style="text-align:left"><a href="/Boutique/voitureDetails/<?php echo e($v->id); ?>">Lien</td>
                <td style="text-align:left"><a id="details" href="/Services/voiturepdf/<?php echo e($v->id); ?>">Détails</a></td>
                <td style="text-align:left"><?php if($v->voitureclick): ?><?php echo e($v->voitureclick->click_nbr); ?><?php else: ?> 0 <?php endif; ?></a></td>
                
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>       
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Admin/Admin_click.blade.php ENDPATH**/ ?>