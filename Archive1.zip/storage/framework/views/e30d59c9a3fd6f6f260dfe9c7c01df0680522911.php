<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title>Boutique</title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>

<div class="container">
    <div class="row ">
        <div class="col-md-5">
            <div class="card-block">
                <div class="user-image car-image">
                    <img src="<?php echo e($voiture->photo); ?>">
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card-block">
                <table class="table-details vendeur">
                    <tr>
                        <td>Vendeur :</td>
                        <td><strong><?php echo e($voiture->user->nom); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Vendeur Email :</td>
                        <td><strong><?php echo e($voiture->user->email); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Vendeur Telephone :</td>
                        <form method="POST" action="<?php echo e(action('VoitureController@NumberClick')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($voiture->id); ?>" name="voiture_id"/>
                            <input type="hidden" value="<?php echo e($voiture->tel); ?>" name="voiture_tel"/>
                            <td><strong><?php echo e($voiture->user->telephone); ?></strong> <input type="image" alt="submit" src="/project_images/phone.png" width="25px"></td>
                        </form>
                    </tr>
                    <tr>
                        <td style="border: none;">Boutique :</td>
                        <td style="border: none;"><strong><u><a href="/Boutique/boutique_voiture/<?php echo e($voiture->boutique->id); ?>"><?php echo e($voiture->boutique->nom_boutique); ?> >></a></u></strong></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    <div class="row ">
        <div class="col-md-8">
            <div class="card-block">
                <div class="card-introduction card_gap">
                    <table class="table-details">
                        <tr>
                            <td>Marque :</td>
                            <td><strong><?php echo e($voiture->marque); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Model :</td>
                            <td><strong><?php echo e($voiture->model); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Version :</td>
                            <td><strong><?php echo e($voiture->version); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Carburant :</td>
                            <td><strong><?php echo e($voiture->carburant); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Boite de vitesse :</td>
                            <td><strong><?php echo e($voiture->boite_vitesse); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Année :</td>
                            <td><strong><?php echo e($voiture->annee); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Origine :</td>
                            <td><strong><?php echo e($voiture->origine); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Kilométrage :</td>
                            <td><strong><?php echo e($voiture->kilometrage); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Couleur :</td>
                            <td><strong><?php echo e($voiture->couleur); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Carrosserie :</td>
                            <td><strong><?php echo e($voiture->carrosserie); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Nombre de portes :</td>
                            <td><strong><?php echo e($voiture->nbr_porte); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Puissance fiscale :</td>
                            <td><strong><?php echo e($voiture->puissance_fiscale); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Première Main :</td>
                            <td><strong><?php echo e($voiture->premiere_main); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Préparé :</td>
                            <td><strong><?php echo e($voiture->prepare); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Description :</td>
                            <td><strong><?php echo e($voiture->description); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Prix :</td>
                            <td><strong><?php echo e($voiture->prix); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Ville :</td>
                            <td><strong><?php echo e($voiture->ville); ?></strong></td>
                        </tr>
                        
                        <?php if($voiture->voitureoccasion): ?>
                        <tr>
                            <td>Options :</td>
                            <td><strong><?php echo e($voiture->options); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Occasion :</td>
                            <td><strong>Oui</strong></td>
                        </tr>
                        <tr>
                            <td style="border: none;">Etat :</td>
                            <td style="border: none;"><strong><?php echo e($voiture->voitureoccasion->etat); ?></strong></td>
                        </tr>
                        
                        <?php else: ?>
                        <tr>
                            <td style="border: none;">Options :</td>
                            <td style="border: none;"><strong><?php echo e($voiture->options); ?></strong></td>
                        </tr>   
                        <?php endif; ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

$(document).ready(function(){
    if (/Mobi/.test(navigator.userAgent)) {
        $("form").prepend('<input type="hidden" name="click_nbr" value="mobile" />');
    }else{
        $("form").prepend('<input type="hidden" name="click_nbr" value="other" />');
    }

});
</script>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/boutique/voitureDetails.blade.php ENDPATH**/ ?>