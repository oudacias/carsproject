<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<link rel="stylesheet" href="/css/confirmation.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title><?php echo e($user->nom); ?></title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="container">
    <div class="row justify-content-around">
        <div class="col-md-4">        
            <div class="card user-card"  style="min-height:355px">
                <div  class="user-image img-home">
                    <img class="img-profile" src="<?php echo e($user->Userimage->image_path); ?>"></div>
                    <form id="profile_form" method="post" action="<?php echo e(action('UserController@modifierProfile')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="image-upload">
                        <label class="change-profile" for="file-inputs">Changer
                        </label>
                        <input id="file-inputs" type="file" name="image" accept="image/x-png,image/jpeg"/>
                        <input type="submit">
                    </div>
                    </form>
                        <div class="card-block">
                            <div class="container">
                                <div class="row justify-content-around">
                                <?php if(Auth::user()->objectif != 'standard' && Auth::user()->confirmer): ?>
                                    <div class="col-md-12">        
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Voitures Vendues</div>
                                                <div class="card-car-number"><?php echo e($user->achatvoiture->count()); ?></div>
                   
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Boutique</div>
                                                    <div class="card-car-number"><?php echo e($user->boutique->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Forum <?php if($user->forum->count()): ?><a href="/User/myForums"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->forum->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Commentaire <?php if($user->forums->count()): ?><a href="/User/myComments"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->forums->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Articles Sauvegardés <?php if($user->articles->count()): ?><a href="/User/myArticles"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->articles->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>                    
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                <div class="container">
                        <div class="row">
                            <div class="col-md-6"><a href="/boutique/nouvelle_boutique">
                                <div class="card profile-card">
                                    Ajouter Boutique<br><br>
                                    <img class="cars_profile" src="/project_images/garage_profile.png"> 
                                </div>               
                            </div></a>
                            <div class="col-md-6"><a href="/boutique/voiture">
                                    <div class="card profile-card">
                                        Ajouter Voiture<br><br>
                                        <img class="cars_profile" src="/project_images/cars_profile.png" >
                                    </div>
                                </div>
                            </div></a>
                        </div>
                    <div class="card user-card">
                        <div class="card-block">
                            <div style="text-align:center">Vos Boutiques</div>   
                            <?php $__currentLoopData = $user->boutique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="boutique-card"><?php echo e($u->nom_boutique); ?>

                                    <div class="arrow-down" id="arrow<?php echo e($u->id); ?>"></div>
                                </div>
                                    <?php if($u->voiture->count()): ?>
                                    <table class="table" id="table<?php echo e($u->id); ?>">
                                        <thead>
                                            <tr>
                                            <th scope="col">Marque</th>
                                            <th scope="col">Model</th>
                                            <th scope="col">Version</th>
                                            <th scope="col">Année</th>
                                            <th scope="col">Confirmé</th>
                                            <th scope="col">Acheté</th>
                                            <th scope="col">Annuler</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $u->voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($v->marque); ?></td>
                                                <td><?php echo e($v->model); ?></td>
                                                <td><?php echo e($v->version); ?></td>
                                                <td><?php echo e($v->annee); ?></td>
                                                <?php if($v->confirme): ?>
                                                    <td>Oui</td>
                                                <?php else: ?>
                                                    <td>Non</td>
                                                <?php endif; ?>
                                                <?php if($v->achatvoiture): ?>
                                                    <td>Oui</td>
                                                <?php else: ?>
                                                    <td>Non</td>
                                                    <td><a href="/Voiture/remove/<?php echo e($v->id); ?>"><img src="/project_images/removeCar.png" width="20%"></a></td>

                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <script>
                                        $(document).ready(function(){
                                            var open = true;
                                            $("#table<?php echo e($u->id); ?>").hide();
                                            $("#arrow<?php echo e($u->id); ?>").click(function(){
                                                if(open){
                                                    $("#table<?php echo e($u->id); ?>").fadeIn();
                                                    open = false;
                                                }else{
                                                    $("#table<?php echo e($u->id); ?>").fadeOut(1);
                                                    open = true;
                                                }                                        
                                            });
                                        });
                                    </script>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                        </div>
                    </div>
                    <?php elseif((Auth::user()->objectif != 'standard' && !Auth::user()->confirmer)): ?>
                        <i><center>Votre demande pour commencer à vendre est en cours</center></i>
                    <?php endif; ?>
                    <?php if(Auth::user()->objectif == 'standard' || !Auth::user()->confirmer): ?>
                                </div>
                            </div>                    
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6"><a href="/User/myArticles">
                                <div class="card profile-card">
                                    Article Farvoris (<?php echo e($user->articles->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/favorite.png"> 
                                </div>               
                            </div></a>
                            <div class="col-md-6"><a href="/User/myForums">
                                <div class="card profile-card">
                                    Forum Ajouté (<?php echo e($user->forum->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/forum.png" >
                                </div>
                            </div>
                        </div></a>
                        <div class="row">
                            <div class="col-md-6"><a href="/User/myComments">
                                <div class="card profile-card">
                                    Commentaire Ajouté (<?php echo e($user->forums->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/comment.png" >
                                </div>
                            </div>
                        </div></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div> 
</div>
<script>
    $('#file-inputs').bind('change', function() {
        $("#profile_form").submit();
    });
</script>






<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/profile.blade.php ENDPATH**/ ?>