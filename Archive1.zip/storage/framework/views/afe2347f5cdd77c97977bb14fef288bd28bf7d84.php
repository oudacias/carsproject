<?php $__env->startSection('dashboard'); ?>
<link rel="stylesheet" href="/css/dashboard.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" type="text/css" href="/css/menu.css">

<div class="row">
    <div class="col-md-4 img-index">
	<img class="logo-menu" src="/project_images/logoCars.png">
		<nav>
			<ul class="mcd-menu" style="padding-top: 100px">
			<p class="admin">Espace Administrateur</p>

				<li>
					<a href="/Admin/Admin_articles">
						Nos articles
					</a>
				</li>
				<li>
					<a href="/Admin/Nouvel_article">
						+ Article
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_forum">Forum</a>
				</li>
				<li>
					<a href="/Admin/Admin_users">
						Utilisateurs
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_diagnostic">
						Diagnostique
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_suivi">
						Suivi
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_boutique">
						Boutiques
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_voiture">
						Voitures
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_click">
						Voitures click
					</a>
				</li>
				<li>
					<a href="/Admin/Admin_contact">
						Messages
					</a>
				</li>
			</ul>
		</nav>
    </div>
<div class="container13">
<label class="dropdown">

<div class="dd-button">
  <img src="/project_images/user.png" width="27px">
</div>
<input type="checkbox" class="dd-input" id="test">
<ul class="dd-menu">
<?php if(Auth::check()): ?>
<li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
Se Déconnecter</a></li>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
	<?php echo csrf_field(); ?>
</form>
<?php endif; ?>
</ul>

  </label>
    <div class="dashboard_container">  
<?php $__env->stopSection(); ?>
    
    </div>
</div>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Components/dashboard.blade.php ENDPATH**/ ?>