<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forumtheme extends Model
{
    //
}
