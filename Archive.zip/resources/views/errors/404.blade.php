<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<title>Error 404</title>
@include('Components.menu')
@yield('menu')
<center><img width="75%" height="87%" src="/project_images/lost_car3.png"/></center>