<!DOCTYPE html>
<html lang="en">
<head>
    <title>Espace Admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">
</head>
<body>
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<div class="container-contact100">
    <div class="wrap-contact100">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <span class="contact100-form-title">Bienvenue Administrateur</span>
                        <div class="wrap-input100 validate-input">
                            <input id='email' class="input100" type="text" name="email" placeholder="Votre Email">
                            <span class="focus-input100"></span>
                        </div>
                        <input id='role' type="text" name="role" value="administrateur" hidden>

                        <div class="wrap-input100 validate-input">
                <input id='password' class="input100" type="password" name="password" placeholder="Votre Mote de Passe">
                <span class="focus-input100"></span>
            </div>
                       
            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">
                    SE CONNECTER
                </button>
            </div>
                    </form>
</div>
</div>
  
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views//auth/login_admin.blade.php ENDPATH**/ ?>