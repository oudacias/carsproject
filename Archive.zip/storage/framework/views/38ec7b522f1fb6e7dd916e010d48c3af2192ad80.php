<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<link rel="stylesheet" href="/css/confirmation.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title><?php echo e($user->nom); ?></title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<?php if(session('success')): ?>
    <div class="animated fadeOut success"><?php echo e(session('success')); ?></div>

<?php endif; ?>

<div class="container">
    <div class="row justify-content-around">
        <div class="col-md-4">        
            <div class="card user-card"  style="min-height:355px;">
            <h4><?php echo e($user->nom); ?> &nbsp; <?php echo e($user->prenom); ?></h4>
                <div  class="user-image img-home">
                    <img class="img-profile" src="<?php echo e($user->Userimage->image_path); ?>"></div>
                    <form id="profile_form" method="post" action="<?php echo e(action('UserController@modifierProfile')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="image-upload">
                        <label class="change-profile" for="file-inputs">Changer
                        </label>
                        <input id="file-inputs" type="file" name="image" accept="image/x-png,image/jpeg"/>
                        <input type="submit">
                    </div>
                    </form>
                        <div class="card-block">
                            <div class="container">
                                <div class="row justify-content-around">
                                <?php if(Auth::user()->objectif != 'standard' && Auth::user()->confirmer): ?>
                                    <div class="col-md-12">        
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Voitures Vendues</div>
                                                <div class="card-car-number"><?php echo e($user->achatvoiture->count()); ?></div>
                   
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Boutique</div>
                                                    <div class="card-car-number"><?php echo e($user->boutique->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Forum <?php if($user->forum->count()): ?><a href="/User/myForums"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->forum->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Nombre Commentaire <?php if($user->forums->count()): ?><a href="/User/myComments"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->forums->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div style="background-color:white" class="card user-card">
                                            <div class="card-block">
                                                <div class="card-car-text">Articles Sauvegardés <?php if($user->articles->count()): ?><a href="/User/myArticles"><img src="/project_images/view1.png" width="20px"></a><?php endif; ?></div>
                                                    <div class="card-car-number"><?php echo e($user->articles->count()); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>                    
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                <div class="container">
                        <div class="row"><?php if(Auth::user()->objectif == 'fournisseur'): ?>
                            <div class="col-md-6"><a href="/boutique/nouvelle_boutique">
                                <div class="card profile-card">
                                    Ajouter Boutique<br><br>
                                    <img class="cars_profile" src="/project_images/garage_profile.png"> 
                                </div>               
                            </div></a><?php endif; ?>
                            <div class="col-md-6"><a href="/boutique/voiture">
                                    <div class="card profile-card">
                                        Ajouter Voiture<br><br>
                                        <img class="cars_profile" src="/project_images/cars_profile.png" >
                                    </div>
                                </div>
                            </div></a>
                        </div>
                    <?php if(Auth::user()->objectif == 'fournisseur' && $user->boutique->count()): ?>
                    <div class="card user-card">
                        <div class="card-block">
                            <div style="text-align:center">Vos Boutiques</div>   
                            <?php $__currentLoopData = $user->boutique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="boutique-card"><?php echo e($u->nom_boutique); ?> (<?php echo e($u->voiture->count()); ?> voitures) 
                                    <img id="info_boutiques<?php echo e($u->id); ?>" style="float:right;margin-right:16%" width="25px" src="/project_images/edit_file.png"/>
                                    <img id="remove_boutiques<?php echo e($u->id); ?>" style="float:right;margin-right:5%" width="25px" src="/project_images/removeCar.png"/></a>
                                    <div class="arrow-down" id="arrow<?php echo e($u->id); ?>"></div>
                                </div>
                                <div id="supprimerBoutique<?php echo e($u->id); ?>" style="background-color:white;border-radius:20px;padding:40px">
                                        <center>Supprimer la boutique va automatiquement
                                        <br>supprimer les voitures de la boutique<center>
                                        <br>
                                        <div class="container-contact100-form-btn">
                                            <button class="contact100-form-btn">
                                                <a href="/profile/supprimerBoutique/<?php echo e($u->id); ?>">Supprimer</a>
                                            </button>
                                        </div>
                                </div>
                                <script>
                                    $(document).ready(function(){
                                        $("#supprimerBoutique<?php echo e($u->id); ?>").hide();
                                        $("#remove_boutiques<?php echo e($u->id); ?>").click(function(){
                                            $("#table<?php echo e($u->id); ?>").hide();
                                            $("#info_boutique<?php echo e($u->id); ?>").hide();
                                            $("#supprimerBoutique<?php echo e($u->id); ?>").toggle();
                                        });

                                    });
                                </script>
                                <div id="info_boutique<?php echo e($u->id); ?>" class="container-contact100" style="background-color:white;border-radius:20px">
                                <div class="container">
                                    <div class="row justify-content-around">
                                        <div class="col-md-4">        
                                                <div  class="user-image img-home">
                                                    <img class="img-profile" src="<?php echo e($u->lien_image); ?>"></div>
                                                    <form id="image_form<?php echo e($u->id); ?>" method="post" action="<?php echo e(action('BoutiqueController@modifierImage')); ?>" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="image-upload">
                                                            <br>
                                                            <br>
                                                            <label class="image-boutique-label" for="file-inputs<?php echo e($u->id); ?>">Changer
                                                            </label>
                                                            <input type="hidden" name="boutique_id" value="<?php echo e($u->id); ?>"/>
                                                            <input id="file-inputs<?php echo e($u->id); ?>" type="file" name="imageBoutique" accept="image/x-png,image/jpeg"/>
                                                            <input type="submit">
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                    </div>

                                
                                    <form class="contact100-form validate-form" method="post" action="<?php echo e(action('BoutiqueController@modifyBoutique')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                        <input type="texte" name="id_boutique" value="<?php echo e($u->id); ?>" hidden>
                                        <label class="info-boutique-label">Nom de la boutique</label> 
                                        <br>
                                        <span class="alert" id="alert1<?php echo e($u->id); ?>">Veuillez Remplire ce Champ</span>  
                                        <div class="wrap-input100 validate-input" >
                                            <input class="input100" id="nom_boutique<?php echo e($u->id); ?>" type="text" name="nom_boutique" value="<?php echo e($u->nom_boutique); ?>" placeholder="Nom Boutique">
                                            <span class="focus-input100"></span>
                                        </div>
                                        <label class="info-boutique-label">Description de la boutique</label>
                                        <br>
                                        <span class="alert" id="alert2<?php echo e($u->id); ?>">Veuillez Remplire ce Champ</span>
                                        <div class="wrap-input100 validate-input">
                                            <textarea class="input100" id="description_boutique<?php echo e($u->id); ?>" style="min-height:150px" name="description_boutique" placeholder="Description Boutique"><?php echo e($u->description_boutique); ?></textarea>
                                            <span class="focus-input100"></span>
                                        </div>
                                        <label class="info-boutique-label">Ville de la boutique</label>  
                                        <br>
                                        <span class="alert" id="alert3<?php echo e($u->id); ?>">Veuillez Remplire ce Champ</span>
                                        <div class="wrap-input100 validate-input" >
                                            <input class="input100" id="ville_boutique<?php echo e($u->id); ?>" type="text" name="ville_boutique" value="<?php echo e($u->ville_boutique); ?>">
                                            <span class="focus-input100"></span>
                                        </div>
                                        <div class="container-contact100-form-btn">
                                            <button class="contact100-form-btn">
                                                Modifier Boutique
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                    <script>
                                         $(document).ready(function(){
                                            $("#info_boutique<?php echo e($u->id); ?>").hide();
                                            $("#alert1<?php echo e($u->id); ?>").hide();
                                            $("#alert2<?php echo e($u->id); ?>").hide();
                                            $("#alert3<?php echo e($u->id); ?>").hide();
                                            $("#info_boutiques<?php echo e($u->id); ?>").click(function(){
                                                $("#table<?php echo e($u->id); ?>").hide();
                                                $("#supprimerBoutique<?php echo e($u->id); ?>").hide();
                                                $("#info_boutique<?php echo e($u->id); ?>").toggle()                                
                                            });   
                                            
                                            $('#file-inputs<?php echo e($u->id); ?>').bind('change', function() {
                                                document.getElementById('image_form<?php echo e($u->id); ?>').submit(); 
                                                console.log('<?php echo e($u->id); ?>')
                                            });


                                            $("#form").submit(function(e){
                                                if($("#nom_boutique<?php echo e($u->id); ?>").val().length == 0){
                                                    $("#alert1<?php echo e($u->id); ?>").show();
                                                    document.getElementById("alert1<?php echo e($u->id); ?>").style.color = "red";
                                                    e.preventDefault();
                                                }else{
                                                    $("#alert1<?php echo e($u->id); ?>").hide();
                                                }
                                                if($("#description_boutique<?php echo e($u->id); ?>").val().length == 0){
                                                    $("#alert2<?php echo e($u->id); ?>").show();
                                                    document.getElementById("alert2<?php echo e($u->id); ?>").style.color = "red";
                                                    e.preventDefault();
                                                }else{
                                                    $("#alert2<?php echo e($u->id); ?>").hide();
                                                } 
                                                if($("#ville_boutique<?php echo e($u->id); ?>").val().length == 0){
                                                    $("#alert3<?php echo e($u->id); ?>").show();
                                                    document.getElementById("alert3<?php echo e($u->id); ?>").style.color = "red";
                                                    e.preventDefault();
                                                }else{
                                                    $("#alert3<?php echo e($u->id); ?>").hide();
                                                } 
                                            });
                                        });
                                           
                                    </script>
                                    <?php if($u->voiture->count()): ?>
                                    <table class="table" id="table<?php echo e($u->id); ?>">
                                        <thead>
                                            <tr>
                                            <th scope="col">Model</th>
                                            <th scope="col">Lien</th>
                                            <th scope="col">Acheté</th>
                                            <th scope="col">Annuler</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $u->voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($v->model); ?></td>
                                                <td><u><a href="/Boutique/voitureDetails/<?php echo e($v->id); ?>">Lien</a></u></td>
                                                <?php if($v->achatvoiture): ?>
                                                    <td>Oui</td>
                                                <?php else: ?>
                                                    <td>Non</td>
                                                    <td><a href="/Voiture/remove/<?php echo e($v->id); ?>"><img src="/project_images/removeCar.png" width="20%"></a></td>

                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <script>
                                        $(document).ready(function(){
                                            $("#table<?php echo e($u->id); ?>").hide();
                                            $("#arrow<?php echo e($u->id); ?>").click(function(){
                                                $("#info_boutique<?php echo e($u->id); ?>").hide();
                                                $("#supprimerBoutique<?php echo e($u->id); ?>").hide();
                                                $("#table<?php echo e($u->id); ?>").toggle();                                     
                                            });
                                        });
                                    </script>
                                    <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                        </div>
                    </div>
                        <?php elseif(Auth::user()->objectif == 'particulier'): ?>
                        <div class="card user-card">
                            <div class="card-block">
                                <div style="text-align:center">Vos Voitures</div>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                            <th scope="col">Model</th>
                                            <th scope="col">Lien</th>
                                            <th scope="col">Acheté</th>
                                            <th scope="col">Annuler</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = Auth::user()->voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($v->model); ?></td>
                                                <td><u><a href="/Boutique/voitureDetails/<?php echo e($v->id); ?>">Lien</a></u></td>
                                                <?php if($v->achatvoiture): ?>
                                                    <td>Oui</td>
                                                <?php else: ?>
                                                    <td>Non</td>
                                                    <td><a href="/Voiture/remove/<?php echo e($v->id); ?>"><img src="/project_images/removeCar.png" width="20%"></a></td>

                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php elseif((Auth::user()->objectif != 'standard' && !Auth::user()->confirmer)): ?>
                        <i><center>Votre demande pour commencer à vendre est en cours</center></i>
                    <?php endif; ?>
                    <?php if(Auth::user()->objectif == 'standard' || !Auth::user()->confirmer): ?>
                                </div>
                            </div>                    
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6"><?php if($user->articles->count()): ?><a href="/User/myArticles"><?php endif; ?>
                                <div class="card profile-card">
                                    Article Farvoris (<?php echo e($user->articles->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/favorite.png"> 
                                </div>               
                            </div></a>
                            <div class="col-md-6"><?php if($user->forum->count()): ?><a href="/User/myForums"><?php endif; ?>
                                <div class="card profile-card">
                                    Forum Ajouté (<?php echo e($user->forum->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/forum.png" >
                                </div>
                            </div>
                        </div></a>
                        <div class="row">
                            <div class="col-md-6"><?php if($user->forums->count()): ?><a href="/User/myComments"><?php endif; ?>
                                <div class="card profile-card">
                                    Commentaire Ajouté (<?php echo e($user->forums->count()); ?>)<br><br>
                                    <img class="cars_profile" src="/project_images/comment.png" >
                                </div>
                            </div>
                        </div></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div> 
</div>
<script>
    $('#file-inputs').bind('change', function() {
        $("#profile_form").submit();
    });
    
    
</script>






<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/profile.blade.php ENDPATH**/ ?>