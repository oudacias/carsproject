<link rel='stylesheet' href="/css/popup.css">
<link rel='stylesheet' href="/css/confirmation.css">
<link rel='stylesheet' href="/css/articles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<?php echo $__env->make('Components.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
	<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
	<?php endif; ?>
	<div class="text_header">Liste des Voitures</div>
        <table class="table">
            <thead>
                <tr>
                <th scope="col">Date</th>
                <th scope="col">Client</th>
                <th scope="col">Détails</th>
                <th scope="col">Confirmer</th>
                <th scope="col">Supprimer</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($v->boutique->type_boutique == 'Standard'): ?>
                        <tr style="text-align:left">
                        <td style="text-align:left"><?php echo e($v->created_at->format('d-m-Y')); ?></td>
                        <td style="text-align:left"><?php echo e($v->boutique->user->nom); ?> &nbsp <?php echo e($v->boutique->user->prenom); ?></td>
                        <td style="text-align:left"><a id="details" href="/Services/voiturepdf/<?php echo e($v->id); ?>">Détails</a></td>
                        <td style="text-align:left"><a href="/Admin/confirmer_voiture/<?php echo e($v->id); ?>"><img src="/project_images/confirm.png" width="20%"></td>
                        <td style="text-align:left"><a href="/Admin/supprimer_voiture/{{$v->id"><img src="/project_images/bin.png" width="20%"></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>       
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Admin/Admin_voiture.blade.php ENDPATH**/ ?>