<!DOCTYPE html>
<html lang="en">
<head>
    <title>Articles</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/articles.css')); ?>">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>


<div class="container-contact100">
    <div class="wrap-contact100">
        <form class="contact100-form validate-form">
				<span class="contact100-form-title">
					Ajouter Article
				</span>

            <div class="wrap-input100 validate-input" data-validate="Please enter your name">
                <input class="input100" type="text" name="titre" placeholder="Titre">
                <span class="focus-input100"></span>
            </div>

            <div class="wrap-input100 validate-input" data-validate = "Please enter your message">
                <textarea class="input100" name="article" placeholder="Rédiger Article"></textarea>
                <span class="focus-input100"></span>
            </div>
            <div class="wrap-input100 validate-input" data-validate="Please enter your name">


                <input class="input100" type="text" name="lien" placeholder="Lien Youtube">
                <span class="focus-input100"></span>
            </div>


            <div class="image-upload">
                <label for="file-input">
                    <img src="images/landscape.png"/>
                </label>

                <input id="file-input" type="file"/>
            </div>



            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">
                    Ajouter Article
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\CarsProject\resources\views/Articles/new_articles.blade.php ENDPATH**/ ?>