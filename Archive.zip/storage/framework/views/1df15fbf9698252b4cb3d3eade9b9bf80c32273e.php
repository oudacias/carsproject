<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title>Boutique</title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>

<h1><?php echo e($boutique->nom_boutique); ?></h1>
<div class="container">

<?php $__currentLoopData = $boutique->voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row boutique-border">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-block">
                        <div class="user-image car-image">
                            <img src="<?php echo e($b->photo); ?>">
                        </div>
                    </div>
                </div>
            <div class="col-md-8 info-border">
                <div class="card-block">
                    <div class="card-introduction card_gap">
                        <p class="m-t-13 text-muted">
                        Marque : <strong><?php echo e($b->marque); ?></strong><br>
                        Model : <strong><?php echo e($b->model); ?></strong><br>
                        Description : <strong><?php echo e($b->description); ?></strong><br>
                        Prix : <strong><?php echo e($b->prix); ?></strong><br>
                        Vendeur : <strong><?php echo e($b->user->email); ?></strong>
                        </p>
                        <a href="/Boutique/voitureDetails/<?php echo e($b->id); ?>"><button class="btn-boutique" type="button">Savoir Plus</button></a>

                    </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/boutique/boutique_voiture.blade.php ENDPATH**/ ?>