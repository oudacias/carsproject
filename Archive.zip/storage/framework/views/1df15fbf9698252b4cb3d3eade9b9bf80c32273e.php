<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<link rel="stylesheet" href="/css/article.css">
<link rel='stylesheet' href="/css/confirmation.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title>Boutique</title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Boutique.rechercheHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<?php echo $__env->yieldContent('recherche'); ?>

    <h2>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($boutique->nom_boutique); ?></h2>
<div class="container other-sides">
<?php if($boutique->voiture->count()): ?>
    <?php $__currentLoopData = $boutique->voiture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="boutique-border">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-block">
                        <div class="user-image car-image">
                            <img src="<?php echo e($v->photo); ?>">
                        </div>
                    </div>
                </div>
            <div class="col-md-8 info-border">
                <div class="card-block">
                    <div class="card-introduction card_gap">
                        <p class="m-t-13 text-muted">
                        Marque : <strong><?php echo e($v->marque); ?></strong><br>
                        Model : <strong><?php echo e($v->model); ?></strong><br>
                        Description : <strong><?php echo e($v->description); ?></strong><br>
                        Prix : <strong><?php echo e($v->prix); ?></strong><br>
                        Vendeur : <strong><?php echo e($v->user->email); ?></strong>
                        </p>
                        <a href="/Boutique/voitureDetails/<?php echo e($v->id); ?>"><button class="btn-boutique" type="button">Savoir Plus</button></a>
                    </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php else: ?>
<br>

    <i>Cette boutique est encore vide</i>

<?php endif; ?>
       
</div>
</body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/boutique/boutique_voiture.blade.php ENDPATH**/ ?>