<link rel='stylesheet' href="/css/popup.css">
<link rel='stylesheet' href="/css/confirmation.css">
<?php echo $__env->make('Components.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
	<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
	<?php endif; ?>
	<div class="text_header">Liste des Messages</div>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Email</th>
      <th scope="col">Sujet</th>
	  <th scope="col">Message</th>
      <th scope="col">Supprimer</th>

    </tr>
  </thead>
  <tbody>
	<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($c->created_at->format('d-m-Y')); ?></td>
      <td><?php echo e($c->email); ?></td>
      <td><?php echo e($c->sujet); ?></td>
      <td><?php echo e($c->texte); ?></td>		
	  <td><a href="/Admin/Admin_contacts/<?php echo e($c->id); ?>"><img src="/project_images/bin.png" width="20%"></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
    
    </div></div>
  </div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Admin/Admin_contact.blade.php ENDPATH**/ ?>