<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">
</head>
<body>
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<div class="container-contact100">
    <div class="wrap-contact100">
   
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
            <span class="contact100-form-title">Confirmer Email</span>
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <span>Un email est envoyé à cette adresse</span>
                </div>
            <?php endif; ?>
            <div class="wrap-input100 validate-input">
                <input id='email' class="input100" type="text" name="email" placeholder="Votre Email">
                <span class="focus-input100"></span>
            </div>
               
            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">
                    Envoyer
                </button>
            </div>
        </form>
    </div>
</div>
  
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>