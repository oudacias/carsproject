<link rel="stylesheet" type="text/css" href="/css/pdf.css">

<h1 style="text-align:center">Diagnostic Voiture</h2>

<table style="font-size:22px">
<tr>
    <td class="width_column">Nom Client</td>
    <td>:<?php echo e($diagnostic->user->nom); ?></td>
</tr>
<tr>
    <td class="width_column">Prénom Client</td>
    <td>:<?php echo e($diagnostic->user->prenom); ?></td>
</tr>
<tr>
    <td class="width_column">Email Client</td>
    <td>:<?php echo e($diagnostic->user->email); ?></td>
</tr>
<tr>
    <td class="width_column">Téléphone Client</td>
    <td>:<?php echo e($diagnostic->user->telephone); ?></td>
</tr>

<tr>
    <td class="width_column">Marque</td>
    <td>:<?php echo e($diagnostic->marque); ?></td>
</tr>
<tr>
    <td class="width_column">Model</td>
    <td>:<?php echo e($diagnostic->model); ?></td>
</tr>

<tr>
    <td class="width_column">Version</td>
    <td>:<?php echo e($diagnostic->version); ?></td>
</tr>
<tr>
    <td class="width_column">Carburant</td>
    <td>:<?php echo e($diagnostic->carburant); ?></td>
</tr>
<tr>
    <td class="width_column">Boite Vitesse</td>
    <td>:<?php echo e($diagnostic->boite_vitesse); ?></td>
</tr>
<tr>
    <td class="width_column">Anneée</td>
    <td>:<?php echo e($diagnostic->annee); ?></td>
</tr>
<tr>
    <td class="width_column">Dédouané</td>
    <td>:<?php echo e($diagnostic->dedouane); ?></td>
</tr>
<tr>
    <td class="width_column">Kilométrage</td>
    <td>:<?php echo e($diagnostic->kilometrage); ?></td>
</tr>
<tr>
    <td class="width_column">Couleur</td>
    <td>:<?php echo e($diagnostic->couleur); ?></td>
</tr>
<tr>
    <td class="width_column">Carosserie</td>
    <td>:<?php echo e($diagnostic->carrosserie); ?></td>
</tr>
<tr>
    <td class="width_column">Nombre Porte</td>
    <td>:<?php echo e($diagnostic->nbr_porte); ?></td>
</tr>
<tr>
    <td class="width_column">Puissance Fiscale</td>
    <td>:<?php echo e($diagnostic->puissance_fiscale); ?></td>
</tr>
<tr>
    <td class="width_column">Première Main</td>
    <td>:<?php echo e($diagnostic->premiere_main); ?></td>
</tr>
<tr>
    <td class="width_column">Préparé</td>
    <td>:<?php echo e($diagnostic->prepare); ?></td>
</tr>
<tr>
    
</table>



<img class="img-car" src="<?php echo e(public_path() . $diagnostic->photo); ?>">
<h2 style="text-align:center">Photo Voiture</h2>

<style>
    table{
    margin-left:200px;
    width: 700px;
    margin-top:50px;

}
    .width_column{
        width:40%;
        padding-right:40px;
    }
    .img-car{
        margin-top: 50px;
        width:70%;
        height:auto;
        margin-left:75px;
    }
    
</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Services/diagnosticpdf.blade.php ENDPATH**/ ?>