<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<link rel="stylesheet" href="/css/confirmation.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<title>Mes Forums</title>

<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<?php if(session('success')): ?>
		<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<div class="container">
<?php $__currentLoopData = $user->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row card_gap">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-block">
                        <div class="user-image article-image">
                            <img src="<?php echo e($u->lien_image); ?>">
                        </div>
                    </div>
                </div>
            <div class="col-md-4">
                <div class="card-block">
                    <div class="card-introduction">
                        <strong><?php echo e($u->titre); ?></strong>
                        <p class="m-t-13 text-muted"><?php echo html_entity_decode(Str::limit($u->texte, 450)); ?></p><a href="/Articles/Article/<?php echo e($u->id); ?>">Lire Plus</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <a href="/User/SupprimerFavoris/<?php echo e($u->pivot->id); ?>"><img style="margin-top:30%;margin-left:90%" src="/project_images/trash.png" width="20%"></a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views//User/myArticles.blade.php ENDPATH**/ ?>