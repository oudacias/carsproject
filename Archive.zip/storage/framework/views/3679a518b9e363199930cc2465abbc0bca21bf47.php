<link rel="stylesheet" type="text/css" href="/css/pdf.css">
<?php $path = "/project_images/logoCars.png" ?>
<img class="logo-car" src="<?php echo e(public_path() .  $path); ?>">
<div class="brand-car">ELAMDASSI ON CARS</div>

<h1 style="text-align:center">Vente Voiture</h2>

<table style="font-size:22px">
<tr>
    <td class="width_column">Nom Client</td>
    <td>:<?php echo e($voiture->user->nom); ?></td>
</tr>
<tr>
    <td class="width_column">Prénom Client</td>
    <td>:<?php echo e($voiture->user->prenom); ?></td>
</tr>
<tr>
    <td class="width_column">Téléphone Client</td>
    <td>:<?php echo e($voiture->user->telephone); ?></td>
</tr>
<tr>
    <td class="width_column">Version</td>
    <td>:<?php echo e($voiture->version); ?></td>
</tr>
<tr>
    <td class="width_column">Carburant</td>
    <td>:<?php echo e($voiture->carburant); ?></td>
</tr>
<tr>
    <td class="width_column">Boite de Vitesse</td>
    <td>:<?php echo e($voiture->boite_vitesse); ?></td>
</tr>
<tr>
    <td class="width_column">Année</td>
    <td>:<?php echo e($voiture->annee); ?></td>
</tr>
<tr>
    <td class="width_column">Origine</td>
    <td>:<?php echo e($voiture->origine); ?></td>
</tr>
<tr>
    <td class="width_column">Kilomètre parcourus</td>
    <td>:<?php echo e($voiture->kilometrage); ?></td>
</tr>
<tr>
    <td class="width_column">Couleur</td>
    <td>:<?php echo e($voiture->couleur); ?></td>
</tr>
<tr>
    <td class="width_column">Carrosserie</td>
    <td>:<?php echo e($voiture->carrosserie); ?></td>
</tr>

<tr>
    <td class="width_column">Nombre Portes</td>
    <td>:<?php echo e($voiture->nbr_porte); ?></td>
</tr>
<tr>
    <td class="width_column">Puissance Fiscale</td>
    <td>:<?php echo e($voiture->puissance_fiscale); ?></td>
</tr>
<tr>
    <td class="width_column">Premiere Main</td>
    <td>:<?php echo e($voiture->premiere_main); ?></td>
</tr>
<tr>
    <td class="width_column">Préparé</td>
    <td>:<?php echo e($voiture->prepare); ?></td>
</tr>
<tr>
    <td class="width_column">Description</td>
    <td>:<?php echo e($voiture->description); ?></td>
</tr>
<tr>
    <td class="width_column">Prix</td>
    <td>:<?php echo e($voiture->prix); ?></td>
</tr>
<tr>
    <td class="width_column">Options Voiture</td>
    <td>:<?php echo e($voiture->options); ?></td>
</tr>
<tr>
    <td class="width_column">Ville Voiture</td>
    <td>:<?php echo e($voiture->ville); ?></td>
</tr>
<tr>
    <td class="width_column">Type Voiture</td>
    <?php if(!$voiture->voitureoccasion): ?>
    <td>:Neuve</td>
    <?php else: ?>
    <td>:Occasion</td>
</tr>
<tr>
    <td class="width_column">Etat Voiture</td>
    <td>:<?php echo e($voiture->voitureoccasion->etat); ?></td>
</tr>
<?php endif; ?> 
</table>
<img class="img-car" src="<?php echo e(public_path() . $voiture->photo); ?>">
<?php if($voiture->voitureimage): ?>
<?php $__currentLoopData = $voiture->voitureimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img class="img-car" src="<?php echo e(public_path() . $v->image1); ?>">
    <?php if($v->image2): ?>
        <img class="img-car" src="<?php echo e(public_path() . $v->image2); ?>">
    <?php endif; ?>
    <?php if($v->image3): ?>
        <img class="img-car" src="<?php echo e(public_path() . $v->image3); ?>">
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<style>

table{
    margin-left:200px;
    width: 700px;
    margin-top:50px;

    }
    .width_column{
        width:40%;
        padding-right:40px;
    }
    .img-car{
        margin-top: 50px;
        width:30%;
        height:auto;
        margin-left:95px;
    }
    .logo-car{
        width:20%;
    }
    .brand-car{
        color:#FAB107;
        font-size:30px;
        text-align:center;
    }

</style>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Services/voiturepdf.blade.php ENDPATH**/ ?>