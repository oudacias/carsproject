<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p><?php echo e($details['pass']); ?></p>
   
    <a href="eocars.ma">www.eocars.ma</a>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/emails/myTestMail.blade.php ENDPATH**/ ?>