<head>
    <title><?php echo e($artc->titre); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">

    <link rel="stylesheet" type="text/css" href="/css/card.css">
    <link rel="stylesheet" type="text/css" href="/css/mainstyle.css">
    <link rel="stylesheet" type="text/css" href="/css/article.css">
    <link rel="stylesheet" type="text/css" href="/css/social.css">
    <link rel="stylesheet" type="text/css" href="/css/popup.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='https://rawgit.com/Belyash/jquery-social-buttons/master/src/jquery.social-buttons.min.js'></script>
</head>
<body>
    <?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('menu'); ?>


    <div class="container">
        <div class="row justify-content-around">
            <h1 id="titres"><?php echo e($artc->titre); ?></h1></div>
            <div class="header-banner" style="background-image: url('<?php echo e($artc->lien_image); ?>')"></div>
            <div class="row justify-content-around">
                <div class="col-md-12"> 
                    <div class="card user-card">
                        <div class="card-block">
                            <div class="card-introduction"><p class="m-t-13 text-muted">
                                <?php echo html_entity_decode($artc->texte); ?>

                                
                        </div>
                        <?php if($artc->lien_youtube): ?>
                        <div class="container">
                            <input type="hidden" id="youtube" value = "<?php echo e($artc->lien_youtube); ?>" />
                            <iframe  id="video" class="video" frameborder="0" style="display: none"
                            allowfullscreen></iframe>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                </div>
            
            <?php if(Auth::check()): ?>
                <?php if($artc->user->count()): ?>
                    <h6 style="color:#441800">C'est article est dans votre collection de <u><a href="/User/myArticles">favoris</a></u></h6>
                <?php else: ?>
                    <h5 style="color:#FAB107">Ajouter au favoris : <a href="/User/AjouterArticle/<?php echo e($artc->id); ?>"><img src="/project_images/heart1.png" width="40px"></a></h5>
                <?php endif; ?>
            <?php else: ?>
                <h5 style="color:#FAB107">Ajouter au favoris : <a href="#new"><img src="/project_images/heart1.png" width="40px"></a></h5>
                <div id="new" class="overlay">
                    <div class="popup" style="margin-top:300px">
                        <a class="close_forum" href="#">&times;</a>
                        <div class="container-contact100 container_connect" >
                            <div class="wrap-forum">
                                Veuillez vous <a href="/login"><i><u>connecter</u></i></a>
                            </div>
                        </div>
                    </div>
                </div>          
            <?php endif; ?>
            <p style="color:#FAB107">Partagez l'article :
            <span class="twitter-share" data-js="twitter-share"><i class="fab fa-twitter"></i>&nbsp; Partager sur Twitter</span>
            <span class="facebook-share" data-js="facebook-share"><i class="fab fa-facebook"></i>&nbsp; Partager sur Facebook</span>
            <?php if($articles->count()): ?>
            <div class="container">
                <h4>Articles qui peuvent vous intéresser</h4>
                <div class="row">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="row">
                            <div class="col-md-3"><img class="cars_article" src="<?php echo e($a->lien_image); ?>"></div>
                                <div class="col-md-8 article_card"><h8><strong><?php echo e($a->titre); ?></strong></h8>
                                    <p class="m-t-13 text-muted"><?php echo html_entity_decode(Str::limit($a->texte, 150)); ?></p><a href="/Articles/Article/<?php echo e($a->id); ?>">Lire Plus</a>
                                </div>
                            </div>
                        </div>               
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
<script>


$(document).ready(function(){
    var url = $("#youtube").val();
    url = url.split('v=')[1];
    $("#video")[0].src = "https://www.youtube.com/embed/" + url;
    $("#video").show();


    var twitterShare = document.querySelector('[data-js="twitter-share"]');

    twitterShare.onclick = function(e) {
    e.preventDefault();
    var twitterWindow = window.open('https://twitter.com/share?url=' + document.URL, 'twitter-popup', 'height=350,width=600');
    if(twitterWindow.focus) { twitterWindow.focus(); }
        return false;
    }

    var facebookShare = document.querySelector('[data-js="facebook-share"]');

    facebookShare.onclick = function(e) {
    e.preventDefault();
    var facebookWindow = window.open('https://www.facebook.com/sharer/sharer.php?u=' + document.URL, 'facebook-popup', 'height=350,width=600');
    if(facebookWindow.focus) { facebookWindow.focus(); }
        return false;
    }
});
</script>
    

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Articles/Article.blade.php ENDPATH**/ ?>