<link rel="stylesheet" type="text/css" href="/css/pdf.css">
<?php $path = "/project_images/logoCars.png" ?>
<img class="logo-car" src="<?php echo e(public_path() .  $path); ?>">
<div class="brand-car">ELAMDASSI ON CARS</div>

<h1 style="text-align:center">Suivi Voiture</h2>

<table style="font-size:22px">
<tr>
    <td class="width_column">Nom Client</td>
    <td>:<?php echo e($suivi->nom); ?></td>
</tr>
<tr>
    <td class="width_column">Prénom Client</td>
    <td>:<?php echo e($suivi->prenom); ?></td>
</tr>
<tr>
    <td class="width_column">Téléphone Client</td>
    <td>:<?php echo e($suivi->telephone); ?></td>
</tr>
<tr>
    <td class="width_column">Ville Client</td>
    <td>:<?php echo e($suivi->ville); ?></td>
</tr>
<tr>
    <td class="width_column">Client</td>
    <td>:<?php echo e($suivi->sexe); ?></td>
</tr>
<tr>
    <td class="width_column">Age Client</td>
    <td>:<?php echo e($suivi->age); ?></td>
</tr>
<tr>
    <td class="width_column">Situation Familiale</td>
    <td>:<?php echo e($suivi->situation_familiale); ?></td>
</tr>

<tr>
    <td class="width_column">Kilomètre parcourus</td>
    <td>:<?php echo e($suivi->km_parcouru); ?></td>
</tr>
<tr>
    <td class="width_column">Type Route</td>
    <td>:<?php echo e($suivi->type_route); ?></td>
</tr>

<tr>
    <td class="width_column">Place</td>
    <td>:<?php echo e($suivi->places); ?></td>
</tr>
<tr>
    <td class="width_column">Espace Bagage</td>
    <td>:<?php echo e($suivi->bagages); ?></td>
</tr>
<tr>
    <td class="width_column">Type Usage</td>
    <td>:<?php echo e($suivi->type_usage); ?></td>
</tr>
<tr>
    <td class="width_column">Budget</td>
    <td>:<?php echo e($suivi->budget); ?></td>
</tr>
<tr>
    <td class="width_column">Type Financement</td>
    <td>:<?php echo e($suivi->type_financement); ?></td>
</tr>
<tr>
    <td class="width_column">Justification</td>
    <td>:<?php echo e($suivi->justification); ?></td>
</tr>
<tr>
    <td class="width_column">Type Voiture</td>
    <td>:<?php echo e($suivi->type_voiture); ?></td>
</tr>
<tr>
    <td class="width_column">Pourquoi Type Voiture</td>
    <td>:<?php echo e($suivi->pourquoi_type_voiture); ?></td>
</tr>
<tr>
    <td class="width_column">Type Carburant</td>
    <td>:<?php echo e($suivi->type_carburant); ?></td>
</tr>
<tr>
    <td class="width_column">Idée Crédit</td>
    <td>:<?php echo e($suivi->idee_crédit); ?></td>
</tr>
<tr>
    <td class="width_column">Choix Voiture</td>
    <td>:<?php echo e($suivi->voiture_preference); ?></td>
</tr>
<tr>
    <td class="width_column">Pourquoi Choix Voiture</td>
    <td>:<?php echo e($suivi->pourquoi_voiture_preference); ?></td>
</tr>
  
</table>

<style>

table{
    margin-left:200px;
    width: 700px;
    margin-top:50px;

    }
    .width_column{
        width:40%;
        padding-right:40px;
    }
    .img-car{
        margin-top: 50px;
        width:30%;
        height:auto;
        margin-left:95px;
    }
    .logo-car{
        width:20%;
    }
    .brand-car{
        color:#FAB107;
        font-size:30px;
        text-align:center;
    }

</style>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Services/suivipdf.blade.php ENDPATH**/ ?>