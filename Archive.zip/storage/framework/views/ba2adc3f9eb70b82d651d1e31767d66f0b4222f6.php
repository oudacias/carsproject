<link rel="stylesheet" href="/css/mainstyle.css">
<link rel="stylesheet" href="/css/card.css">
<link rel="stylesheet" href="/css/popup.css">
<link rel="stylesheet" href="/css/articles.css">
<title>Error 404</title>
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<center><img width="75%" height="87%" src="/project_images/lost_car3.png"/></center><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/errors/404.blade.php ENDPATH**/ ?>