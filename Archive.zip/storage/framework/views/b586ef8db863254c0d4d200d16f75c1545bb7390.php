<!DOCTYPE html>
<html lang="en">
<head>
    <title>Articles</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">
    <link rel='stylesheet' href="/css/confirmation.css">

</head>
<body>
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<div class="container-contact100">
    <div class="wrap-contact100">
        <form method="POST" action="<?php echo e(action('UserController@AddContact')); ?>">
        <?php echo csrf_field(); ?>
        
            <h3 style="color:#FAB107">Une question ? Une proposition ? Envoyez-nous un message :)</h3>
            <br>
            <?php if(session('success')): ?>
		        <div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
	        <?php endif; ?>
            
            <div class="wrap-input100 validate-input">
                <?php if(Auth::check()): ?>
                    <input class="input100" type="text" name="email" value="<?php echo e(Auth::user()->email); ?>" readonly>
                <?php else: ?>
                    <input class="input100" type="text" name="email" placeholder="Votre Email" required>
                <?php endif; ?>
                <span class="focus-input100"></span>
            </div>
            <div class="wrap-input100 validate-input">
                <input class="input100" type="text" name="sujet" placeholder="Votre Sujet" required>
                <span class="focus-input100"></span>
            </div>
            <div class="wrap-input100 validate-input">
                <textarea class="text-contact" name="texte" placeholder="Votre Texte" required></textarea>
                <span class="focus-input100"></span>

            </div>  
            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">
                    Envoyer
                </button>
            </div>
        </form>
    </div>
</div>

<script>


    
</script>

  
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Contact/contact.blade.php ENDPATH**/ ?>