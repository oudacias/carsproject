<html>
<body>
    <h3>Vous recevez cet e-mail car nous avons reçu une demande de réinitialisation de mot de passe 
    pour votre compte. Merci de suivre ce lien pour changer votre mot de passe.
    <br>
    >><a href="<?php echo e($actionUrl); ?>">Changer mot de passe</a>
    </h3>   
</body>

</html>






<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/vendor/laravel/framework/src/Illuminate/Notifications/resources/views/email.blade.php ENDPATH**/ ?>