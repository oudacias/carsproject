var pusher = new Pusher('e22834bea53871f1ab35', {
    cluster: 'mt1',
    encrypted: true
  });