<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Voiture;
use App\Boutique;
use App\Voitureclick;


class VoitureController extends Controller
{
    //

    public function FormVoiture()
    {
        $user = User::find(Auth::id());
        return view('Boutique/voiture',['user'=>$user]);
    }
    public function VoitureDetails($id)
    {
        $voiture = Voiture::find($id);
        return view('Boutique/voitureDetails',['voiture'=>$voiture]);
    }
    public function TrouverBoutique($id)
    {
        $boutique = Boutique::find($id);
        $nom_boutique = Boutique::all();
        return view('Boutique/boutique_voiture',['boutique'=>$boutique,'nom_boutique'=>$nom_boutique]);
    }
    public function NumberClick(Request $r)
    {
        $click = Voitureclick::where('voiture_id','=',$r->voiture_id)->first();
        if($click){
            $click->click_nbr += 1;
        }else{
            $click = new Voitureclick();
            $click->voiture_id = $r->voiture_id;
            $click->click_nbr = 1;
        }
        $click->save();

        if($r->click_nbr == 'mobile'){
            return redirect()->away("whatsapp://send?phone=".$r->tel);
        }else{
            return redirect()->away("https://web.whatsapp.com/send?phone=".$r->t);
        }
        
    }
}
