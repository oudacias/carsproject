<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Companysocial extends Model
{
    //
}
