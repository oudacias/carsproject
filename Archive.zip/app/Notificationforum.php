<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notificationforum extends Model
{
    //
}
