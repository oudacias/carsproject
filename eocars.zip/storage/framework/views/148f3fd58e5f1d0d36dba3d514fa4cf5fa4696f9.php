<!DOCTYPE html>
<html lang="en">
<head>
    <title>Articles</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/articles.css')); ?>">
    <link rel="stylesheet" type="text/css" href="/css/articles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php echo $__env->make('Components.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('dashboard'); ?>
<?php if(session('success')): ?>
	<div class="animated fadeOut success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<div class="container-contact100">
    <div class="wrap-contact100">
        <form class="contact100-form validate-form" method="post" action="<?php echo e(action('AdminController@ModifierArticle')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
			<span class="contact100-form-title">
				Modifier Article
            </span>
            <input type="texte" name="id_article" value="<?php echo e($artc->id); ?>" hidden>
            <div class="wrap-input100 validate-input" >
                <input class="input100" type="text" name="titre" placeholder="Titre" value="<?php echo e($artc->titre); ?>">
                <span class="focus-input100"></span>
            </div>
            <div class="wrap-input100 validate-input" data-validate = "Please enter your message">
                <textarea class="input100" name="texte" placeholder="Rédiger Article"><?php echo html_entity_decode($artc->texte); ?></textarea>
                <span class="focus-input100"></span>
            </div>
            <div class="wrap-input100 validate-input" >
                <input class="input100" type="text" name="lien_youtube" placeholder="Lien Youtube" value="<?php echo e($artc->lien_youtube); ?>">
                <span class="focus-input100"></span>
            </div>
            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">
                    <a>Modifier Article</a>
                </button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Admin/ModifierArticle.blade.php ENDPATH**/ ?>