<!DOCTYPE html>
<html lang="en">
<head>
    <title>Articles</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/css/card.css">
    <link rel="stylesheet" type="text/css" href="/css/mainstyle.css">
</head>
<body>
<?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('menu'); ?>
<h4>Nos Articles</h4>
<div class="container">
    <?php $__currentLoopData = $artc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row card_gap">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-block">
                        <div class="user-image article-image">
                            <img src="<?php echo e($a->lien_image); ?>">
                        </div>
                    </div>
                </div>
            <div class="col-md-8">
                <div class="card-block">
                    <div class="card-introduction">
                        <strong><?php echo e($a->titre); ?></strong>
                        <p class="m-t-13 text-muted"><?php echo html_entity_decode(Str::limit($a->texte, 650)); ?></p><a href="/Articles/Article/<?php echo e($a->id); ?>">Lire Plus</a>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
</div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/CarsProject/resources/views/Articles/Articles.blade.php ENDPATH**/ ?>